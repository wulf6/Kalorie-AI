import { int, mysqlEnum, mysqlTable, text, timestamp, varchar } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 * Extend this file with additional tables as your product grows.
 * Columns use camelCase to match both database fields and generated types.
 */
export const users = mysqlTable("users", {
  /**
   * Surrogate primary key. Auto-incremented numeric value managed by the database.
   * Use this for relations between tables.
   */
  id: int("id").autoincrement().primaryKey(),
  /** Manus OAuth identifier (openId) returned from the OAuth callback. Unique per user. */
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * User profile with nutrition targets and goals
 */
export const userProfiles = mysqlTable("userProfiles", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().unique().references(() => users.id, { onDelete: "cascade" }),
  age: int("age"),
  gender: mysqlEnum("gender", ["male", "female", "other"]),
  height: int("height"), // cm
  weight: int("weight"), // kg
  activityLevel: mysqlEnum("activityLevel", ["sedentary", "light", "moderate", "active", "veryActive"]).default("moderate"),
  goalWeight: int("goalWeight"), // kg
  goalTempo: mysqlEnum("goalTempo", ["slow", "moderate", "fast"]).default("moderate"), // weight loss tempo
  dailyWaterGoal: int("dailyWaterGoal").default(2000), // ml
  dailyProteinGoal: int("dailyProteinGoal"), // g
  dailyCarbsGoal: int("dailyCarbsGoal"), // g
  dailyFatGoal: int("dailyFatGoal"), // g
  dailyFiberGoal: int("dailyFiberGoal"), // g
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type UserProfile = typeof userProfiles.$inferSelect;
export type InsertUserProfile = typeof userProfiles.$inferInsert;

/**
 * Daily meal entries
 */
export const meals = mysqlTable("meals", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  date: varchar("date", { length: 10 }).notNull(), // YYYY-MM-DD
  slot: varchar("slot", { length: 50 }).notNull(), // Snídaně, Svačina, Oběd, Svačina 2, Večeře
  foodName: varchar("foodName", { length: 255 }).notNull(),
  portion: int("portion").notNull(), // grams or ml
  kcal: int("kcal"),
  protein: int("protein"), // grams * 10 (stored as int for precision)
  carbs: int("carbs"),
  fat: int("fat"),
  fiber: int("fiber"),
  source: mysqlEnum("source", ["manual", "ai", "barcode", "recipe"]).default("manual"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Meal = typeof meals.$inferSelect;
export type InsertMeal = typeof meals.$inferInsert;

/**
 * Custom recipes/foods created by users
 */
export const customFoods = mysqlTable("customFoods", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  name: varchar("name", { length: 255 }).notNull(),
  ingredients: text("ingredients").notNull(), // JSON: [{name, portion, kcal, protein, carbs, fat, fiber}]
  totalKcal: int("totalKcal"),
  totalProtein: int("totalProtein"),
  totalCarbs: int("totalCarbs"),
  totalFat: int("totalFat"),
  totalFiber: int("totalFiber"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type CustomFood = typeof customFoods.$inferSelect;
export type InsertCustomFood = typeof customFoods.$inferInsert;

/**
 * Weight history for tracking progress
 */
export const weightHistory = mysqlTable("weightHistory", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  date: varchar("date", { length: 10 }).notNull(), // YYYY-MM-DD
  weight: int("weight").notNull(), // kg * 10 (stored as int for precision)
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WeightEntry = typeof weightHistory.$inferSelect;
export type InsertWeightEntry = typeof weightHistory.$inferInsert;

/**
 * Daily water intake tracking
 */
export const waterIntake = mysqlTable("waterIntake", {
  id: int("id").autoincrement().primaryKey(),
  userId: int("userId").notNull().references(() => users.id, { onDelete: "cascade" }),
  date: varchar("date", { length: 10 }).notNull(), // YYYY-MM-DD
  amount: int("amount").notNull(), // ml
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type WaterEntry = typeof waterIntake.$inferSelect;
export type InsertWaterEntry = typeof waterIntake.$inferInsert;