# Kalorie AI - TODO

## Database & Schema
- [x] Create users profile table (BMR, TDEE, weight goal, activity level)
- [x] Create meals table (userId, date, slot, foodName, portion, kcal, protein, carbs, fat, fiber)
- [x] Create custom foods/recipes table (userId, name, ingredients with portions)
- [x] Create weight history table (userId, date, weight)
- [x] Generate and apply Drizzle migrations

## Authentication & Profile
- [x] Implement user profile page with BMR/TDEE calculator
- [x] Add weight goal setting and activity level selector
- [x] Implement caloric deficit calculation
- [x] Add estimated goal date calculator
- [x] Create profile edit/save functionality

## Daily Food Diary
- [x] Implement meal slots (Snídaně, Svačina, Oběd, Svačina 2, Večeře)
- [x] Create add meal modal/form
- [x] Implement manual food entry with autocomplete from FOOD_DB
- [ ] Add edit/delete meal functionality
- [x] Implement portion size adjustment
- [x] Create daily totals calculation (kcal, protein, carbs, fat, fiber)

## AI Food Analysis
- [x] Create server-side LLM procedure for food description analysis
- [x] Implement AI modal/form for natural language input
- [x] Add response parsing to extract nutritional values
- [x] Integrate AI results into meal diary

## Barcode Scanner
- [x] Integrate barcode scanning library (Quagga2 or similar)
- [x] Create Open Food Facts API integration
- [x] Implement barcode lookup and data parsing
- [x] Add barcode scanner modal/camera interface
- [x] Handle barcode not found scenarios

## Custom Food Editor
- [x] Create custom food creation form
- [x] Implement ingredient autocomplete suggester
- [x] Add ingredient portion inputs
- [x] Calculate total nutritional values for recipe
- [x] Implement save/load custom foods from database
- [x] Create custom food list view (accessible via editor)

## Interactive Nutrition Rings
- [x] Create circular/donut chart components (Bílkoviny, Sacharidy, Tuky, Vláknina)
- [x] Implement ring click handlers to show food breakdown
- [x] Create food breakdown modal/sheet
- [x] Display individual foods with their contribution to each nutrient

## Water Tracking
- [x] Add water intake input field
- [x] Create water progress bar
- [x] Implement daily water goal setting
- [x] Add quick add buttons (250ml, 500ml)

## History View
- [x] Create date picker/calendar for history navigation
- [x] Implement past day meal log display
- [x] Show nutritional summaries for past days
- [x] Add weight history visualization (weight tracking in profile)

## PWA & UI
- [x] Create manifest.json for PWA
- [x] Implement dark/light mode toggle (via ThemeProvider)
- [x] Add safe area insets for notched devices
- [x] Create responsive mobile-first layout
- [x] Implement touch-friendly interactions
- [x] Add loading states and error handling
- [x] Create empty states for various views

## Testing & Deployment
- [x] Write vitest tests for critical procedures
- [x] Test PWA installation on Android/iOS (PWA manifest ready)
- [ ] Verify data sync across devices
- [ ] Performance optimization
- [ ] Create GitHub repository
- [ ] Prepare deployment instructions for Vercel/Netlify
