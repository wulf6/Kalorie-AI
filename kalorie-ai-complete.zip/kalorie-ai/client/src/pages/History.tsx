import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Loader2, ChevronLeft, ChevronRight } from "lucide-react";
import { Link } from "wouter";
import { useState } from "react";

export default function History() {
  const { isAuthenticated } = useAuth();
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split("T")[0]);

  const { data: meals, isLoading } = trpc.meals.getForDate.useQuery(
    { date: selectedDate },
    { enabled: isAuthenticated }
  );

  const changeDate = (days: number) => {
    const date = new Date(selectedDate);
    date.setDate(date.getDate() + days);
    setSelectedDate(date.toISOString().split("T")[0]);
  };

  const totals = meals?.reduce(
    (acc, meal) => ({
      kcal: acc.kcal + (meal.kcal || 0),
      protein: acc.protein + (meal.protein || 0),
      carbs: acc.carbs + (meal.carbs || 0),
      fat: acc.fat + (meal.fat || 0),
      fiber: acc.fiber + (meal.fiber || 0),
    }),
    { kcal: 0, protein: 0, carbs: 0, fat: 0, fiber: 0 }
  ) || { kcal: 0, protein: 0, carbs: 0, fat: 0, fiber: 0 };

  return (
    <div className="min-h-screen bg-background pb-6">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-card border-b border-border safe-top safe-horizontal">
        <div className="flex items-center gap-4 py-4">
          <Link href="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">Historie</h1>
        </div>
      </div>

      <div className="container max-w-2xl mx-auto px-4 py-6">
        {/* Date Navigation */}
        <Card className="mb-6 p-4">
          <div className="flex items-center justify-between gap-4">
            <Button variant="outline" size="icon" onClick={() => changeDate(-1)}>
              <ChevronLeft className="w-4 h-4" />
            </Button>
            <input
              type="date"
              value={selectedDate}
              onChange={(e) => setSelectedDate(e.target.value)}
              className="input-field flex-1 text-center"
            />
            <Button variant="outline" size="icon" onClick={() => changeDate(1)}>
              <ChevronRight className="w-4 h-4" />
            </Button>
          </div>
        </Card>

        {/* Summary */}
        <Card className="mb-6 p-6">
          <div className="text-center mb-4">
            <div className="text-4xl font-bold text-indigo-600">{totals.kcal}</div>
            <div className="text-muted">kcal</div>
          </div>
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="text-center">
              <div className="font-bold text-blue-500">{totals.protein.toFixed(1)}g</div>
              <div className="text-muted">Bílkoviny</div>
            </div>
            <div className="text-center">
              <div className="font-bold text-amber-500">{totals.carbs.toFixed(1)}g</div>
              <div className="text-muted">Sacharidy</div>
            </div>
            <div className="text-center">
              <div className="font-bold text-green-500">{totals.fat.toFixed(1)}g</div>
              <div className="text-muted">Tuky</div>
            </div>
            <div className="text-center">
              <div className="font-bold text-purple-500">{totals.fiber.toFixed(1)}g</div>
              <div className="text-muted">Vláknina</div>
            </div>
          </div>
        </Card>

        {/* Meals List */}
        {isLoading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="animate-spin w-6 h-6" />
          </div>
        ) : meals && meals.length > 0 ? (
          <div className="space-y-3">
            {meals.map((meal) => (
              <Card key={meal.id} className="p-4">
                <div className="flex justify-between items-start">
                  <div>
                    <div className="font-semibold">{meal.foodName}</div>
                    <div className="text-sm text-muted">{meal.slot} · {meal.portion}g</div>
                  </div>
                  <div className="text-right">
                    <div className="font-bold text-indigo-600">{meal.kcal} kcal</div>
                    <div className="text-xs text-muted">
                      B:{meal.protein?.toFixed(1) || 0}g S:{meal.carbs?.toFixed(1) || 0}g T:{meal.fat?.toFixed(1) || 0}g
                    </div>
                  </div>
                </div>
              </Card>
            ))}
          </div>
        ) : (
          <Card className="p-8 text-center text-muted">
            <p>Žádná jídla v tento den</p>
          </Card>
        )}
      </div>
    </div>
  );
}
