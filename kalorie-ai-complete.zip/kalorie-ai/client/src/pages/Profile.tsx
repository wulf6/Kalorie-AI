import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { ArrowLeft, Loader2 } from "lucide-react";
import { Link } from "wouter";
import { useState, useEffect } from "react";
import { toast } from "sonner";

export default function Profile() {
  const { user } = useAuth();
  const { data: profile, isLoading } = trpc.profile.get.useQuery();
  const updateMutation = trpc.profile.update.useMutation();

  const [formData, setFormData] = useState<{
    age: number;
    gender: "male" | "female" | "other";
    height: number;
    weight: number;
    goalWeight: number;
    activityLevel: "sedentary" | "light" | "moderate" | "active" | "veryActive";
    goalTempo: "slow" | "moderate" | "fast";
    dailyWaterGoal: number;
  }>({
    age: 30,
    gender: "male",
    height: 180,
    weight: 80,
    goalWeight: 75,
    activityLevel: "moderate",
    goalTempo: "moderate",
    dailyWaterGoal: 2000,
  });

  useEffect(() => {
    if (profile) {
      setFormData({
        age: profile.age || 30,
        gender: profile.gender || "male",
        height: profile.height || 180,
        weight: profile.weight || 80,
        goalWeight: profile.goalWeight || 75,
        activityLevel: profile.activityLevel || "moderate",
        goalTempo: profile.goalTempo || "moderate",
        dailyWaterGoal: profile.dailyWaterGoal || 2000,
      });
    }
  }, [profile]);

  const calculateBMR = () => {
    if (formData.gender === "male") {
      return 88.362 + 13.397 * formData.weight + 4.799 * formData.height - 5.677 * formData.age;
    } else {
      return 447.593 + 9.247 * formData.weight + 3.098 * formData.height - 4.33 * formData.age;
    }
  };

  const calculateTDEE = () => {
    const bmr = calculateBMR();
    const activityMultipliers: Record<string, number> = {
      sedentary: 1.2,
      light: 1.375,
      moderate: 1.55,
      active: 1.725,
      veryActive: 1.9,
    };
    return bmr * (activityMultipliers[formData.activityLevel] || 1.55);
  };

  const calculateDeficit = () => {
    const tdee = calculateTDEE();
    const tempoMultipliers: Record<"slow" | "moderate" | "fast", number> = {
      slow: 0.25,
      moderate: 0.5,
      fast: 0.75,
    };
    return tdee * tempoMultipliers[formData.goalTempo];
  };

  const calculateGoalDate = () => {
    const weightDiff = Math.abs(formData.weight - formData.goalWeight);
    const deficit = calculateDeficit();
    const daysNeeded = (weightDiff * 7700) / deficit;
    const goalDate = new Date();
    goalDate.setDate(goalDate.getDate() + Math.round(daysNeeded));
    return goalDate.toLocaleDateString("cs-CZ");
  };

  const bmr = calculateBMR();
  const tdee = calculateTDEE();
  const deficit = calculateDeficit();

  const handleSave = async () => {
    try {
      await updateMutation.mutateAsync({
        age: formData.age,
        gender: formData.gender,
        height: formData.height,
        weight: formData.weight,
        goalWeight: formData.goalWeight,
        activityLevel: formData.activityLevel,
        goalTempo: formData.goalTempo,
        dailyWaterGoal: formData.dailyWaterGoal,
        dailyProteinGoal: Math.round(tdee * 0.3 / 4),
        dailyCarbsGoal: Math.round(tdee * 0.45 / 4),
        dailyFatGoal: Math.round(tdee * 0.25 / 9),
        dailyFiberGoal: 30,
      });
      toast.success("Profil uložen");
    } catch (error) {
      toast.error("Chyba při ukládání profilu");
    }
  };

  if (isLoading) {
    return (
      <div className="flex justify-center items-center min-h-screen">
        <Loader2 className="animate-spin w-6 h-6" />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-6">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-card border-b border-border safe-top safe-horizontal">
        <div className="flex items-center gap-4 py-4">
          <Link href="/">
            <Button variant="ghost" size="icon">
              <ArrowLeft className="w-5 h-5" />
            </Button>
          </Link>
          <h1 className="text-2xl font-bold">Můj profil</h1>
        </div>
      </div>

      <div className="container max-w-2xl mx-auto px-4 py-6">
        {/* Personal Info */}
        <Card className="mb-6 p-6">
          <h2 className="text-lg font-bold mb-4">Osobní údaje</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Věk</label>
              <input
                type="number"
                value={formData.age}
                onChange={(e) => setFormData({ ...formData, age: parseInt(e.target.value) })}
                className="input-field"
              />
            </div>
            <div>
              <label className="block text-sm font-medium mb-1">Pohlaví</label>
              <select
                value={formData.gender}
                onChange={(e) => setFormData({ ...formData, gender: e.target.value as "male" | "female" | "other" })}
                className="input-field"
              >
                <option value="male">Muž</option>
                <option value="female">Žena</option>
                <option value="other">Jiné</option>
              </select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Výška (cm)</label>
                <input
                  type="number"
                  value={formData.height}
                  onChange={(e) => setFormData({ ...formData, height: parseInt(e.target.value) })}
                  className="input-field"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Váha (kg)</label>
                <input
                  type="number"
                  value={formData.weight}
                  onChange={(e) => setFormData({ ...formData, weight: parseInt(e.target.value) })}
                  className="input-field"
                />
              </div>
            </div>
          </div>
        </Card>

        {/* Activity & Goals */}
        <Card className="mb-6 p-6">
          <h2 className="text-lg font-bold mb-4">Aktivita a cíle</h2>
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-1">Úroveň aktivity</label>
              <select
                value={formData.activityLevel}
                onChange={(e) => setFormData({ ...formData, activityLevel: e.target.value as "sedentary" | "light" | "moderate" | "active" | "veryActive" })}
                className="input-field"
              >
                <option value="sedentary">Sedavý</option>
                <option value="light">Lehká</option>
                <option value="moderate">Střední</option>
                <option value="active">Aktivní</option>
                <option value="veryActive">Velmi aktivní</option>
              </select>
            </div>
            <div className="grid grid-cols-2 gap-4">
              <div>
                <label className="block text-sm font-medium mb-1">Cílová váha (kg)</label>
                <input
                  type="number"
                  value={formData.goalWeight}
                  onChange={(e) => setFormData({ ...formData, goalWeight: parseInt(e.target.value) })}
                  className="input-field"
                />
              </div>
              <div>
                <label className="block text-sm font-medium mb-1">Tempo hubnutí</label>
                <select
                  value={formData.goalTempo}
                  onChange={(e) => setFormData({ ...formData, goalTempo: e.target.value as "slow" | "moderate" | "fast" })}
                  className="input-field"
                >
                  <option value="slow">Pomalé</option>
                  <option value="moderate">Střední</option>
                  <option value="fast">Rychlé</option>
                </select>
              </div>
            </div>
          </div>
        </Card>

        {/* Calculations */}
        <Card className="mb-6 p-6 bg-gradient-to-br from-indigo-50 to-blue-50 dark:from-indigo-950 dark:to-blue-950">
          <h2 className="text-lg font-bold mb-4">Výpočty</h2>
          <div className="space-y-3 text-sm">
            <div className="flex justify-between">
              <span>BMR (bazální metabolismus):</span>
              <span className="font-bold">{Math.round(bmr)} kcal/den</span>
            </div>
            <div className="flex justify-between">
              <span>TDEE (denní výdej):</span>
              <span className="font-bold">{Math.round(tdee)} kcal/den</span>
            </div>
            <div className="flex justify-between">
              <span>Kalorický deficit:</span>
              <span className="font-bold">{Math.round(deficit)} kcal/den</span>
            </div>
            <div className="flex justify-between pt-3 border-t border-border">
              <span>Odhadovaný cíl:</span>
              <span className="font-bold">{calculateGoalDate()}</span>
            </div>
          </div>
        </Card>

        {/* Water Goal */}
        <Card className="mb-6 p-6">
          <h2 className="text-lg font-bold mb-4">Hydratace</h2>
          <div>
            <label className="block text-sm font-medium mb-1">Denní cíl vody (ml)</label>
            <input
              type="number"
              value={formData.dailyWaterGoal}
              onChange={(e) => setFormData({ ...formData, dailyWaterGoal: parseInt(e.target.value) })}
              className="input-field"
            />
          </div>
        </Card>

        {/* Save Button */}
        <Button
          onClick={handleSave}
          disabled={updateMutation.isPending}
          className="w-full bg-indigo-600 hover:bg-indigo-700"
        >
          {updateMutation.isPending ? <Loader2 className="animate-spin mr-2 w-4 h-4" /> : null}
          Uložit profil
        </Button>
      </div>
    </div>
  );
}
