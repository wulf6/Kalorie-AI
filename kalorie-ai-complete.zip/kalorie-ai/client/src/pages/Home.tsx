import { useAuth } from "@/_core/hooks/useAuth";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Loader2, Plus, LogOut, Settings, Calendar, Moon, Sun } from "lucide-react";
import { getLoginUrl } from "@/const";
import { useState, useMemo } from "react";
import { Link } from "wouter";
import { toast } from "sonner";
import { AddMealModal } from "@/components/AddMealModal";
import { NutritionDetails } from "@/components/NutritionDetails";
import { MealActions } from "@/components/MealActions";
import { NutritionRings } from "@/components/NutritionRings";
import { BarcodeScanner } from "@/components/BarcodeScanner";
import { CustomFoodEditor } from "@/components/CustomFoodEditor";
import { useTheme } from "@/contexts/ThemeContext";

const MEAL_SLOTS = ["Snídaně", "Svačina", "Oběd", "Svačina 2", "Večeře"];

export default function Home() {
  const { user, logout, isAuthenticated } = useAuth();
  const { theme, toggleTheme } = useTheme();
  const [selectedDate, setSelectedDate] = useState(new Date().toISOString().split("T")[0]);
  const [showAddMeal, setShowAddMeal] = useState(false);
  const [selectedSlot, setSelectedSlot] = useState("Snídaně");
  const [selectedNutrient, setSelectedNutrient] = useState<"protein" | "carbs" | "fat" | "fiber" | null>(null);
  const [expandedMealId, setExpandedMealId] = useState<number | null>(null);
  const [showBarcodeScanner, setShowBarcodeScanner] = useState(false);
  const [showCustomFoodEditor, setShowCustomFoodEditor] = useState(false);

  const utils = trpc.useUtils();

  const { data: meals, isLoading: mealsLoading, refetch: refetchMeals } = trpc.meals.getForDate.useQuery(
    { date: selectedDate },
    { enabled: isAuthenticated }
  );

  const { data: profile } = trpc.profile.get.useQuery(undefined, { enabled: isAuthenticated });
  const { data: waterEntries, refetch: refetchWater } = trpc.water.getForDate.useQuery(
    { date: selectedDate },
    { enabled: isAuthenticated }
  );

  const logoutMutation = trpc.auth.logout.useMutation({
    onSuccess: () => {
      logout();
      toast.success("Odhlášení úspěšné");
    },
  });

  const totals = useMemo(() => {
    if (!meals) return { kcal: 0, protein: 0, carbs: 0, fat: 0, fiber: 0 };
    return meals.reduce(
      (acc, meal) => ({
        kcal: acc.kcal + (meal.kcal || 0),
        protein: acc.protein + (meal.protein || 0),
        carbs: acc.carbs + (meal.carbs || 0),
        fat: acc.fat + (meal.fat || 0),
        fiber: acc.fiber + (meal.fiber || 0),
      }),
      { kcal: 0, protein: 0, carbs: 0, fat: 0, fiber: 0 }
    );
  }, [meals]);

  const waterTotal = useMemo(() => {
    if (!waterEntries) return 0;
    return waterEntries.reduce((acc, entry) => acc + entry.amount, 0);
  }, [waterEntries]);

  const addWaterMutation = trpc.water.add.useMutation({
    onSuccess: () => {
      refetchWater();
      toast.success("Voda přidána");
    },
    onError: () => {
      toast.error("Chyba při přidávání vody");
    },
  });

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 to-blue-50 flex items-center justify-center p-4">
        <Card className="max-w-md w-full p-8 text-center">
          <h1 className="text-3xl font-bold mb-2">Kalorie AI</h1>
          <p className="text-muted mb-6">Inteligentní sledování kalorií a nutričních hodnot</p>
          <Button
            onClick={() => (window.location.href = getLoginUrl())}
            className="w-full bg-indigo-600 hover:bg-indigo-700"
          >
            Přihlásit se
          </Button>
        </Card>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-24">
      {/* Header */}
      <div className="sticky top-0 z-50 bg-card border-b border-border safe-top safe-horizontal">
        <div className="flex items-center justify-between py-4">
          <h1 className="text-2xl font-bold">Kalorie AI</h1>
          <div className="flex gap-2">
            <Button
              variant="ghost"
              size="icon"
              onClick={toggleTheme}
              title={theme === 'dark' ? 'Světlý režim' : 'Tmavý režim'}
            >
              {theme === 'dark' ? <Sun className="w-5 h-5" /> : <Moon className="w-5 h-5" />}
            </Button>
            <Link href="/profile">
              <Button variant="ghost" size="icon">
                <Settings className="w-5 h-5" />
              </Button>
            </Link>
            <Button
              variant="ghost"
              size="icon"
              onClick={() => logoutMutation.mutate()}
              disabled={logoutMutation.isPending}
            >
              <LogOut className="w-5 h-5" />
            </Button>
          </div>
        </div>
      </div>

      {/* Date Selector */}
      <div className="sticky top-16 z-40 bg-card border-b border-border safe-horizontal px-4 py-3">
        <div className="flex items-center gap-2">
          <Calendar className="w-4 h-4 text-muted" />
          <input
            type="date"
            value={selectedDate}
            onChange={(e) => setSelectedDate(e.target.value)}
            className="input-field flex-1"
          />
        </div>
      </div>

      {/* Main Content */}
      <div className="container max-w-2xl mx-auto px-4 py-6">
        {/* Calorie Overview */}
        <Card className="mb-6 p-6">
          <div className="text-center mb-4">
            <div className="text-5xl font-bold text-indigo-600">{totals.kcal}</div>
            <div className="text-muted">/ {profile?.dailyProteinGoal || 2000} kcal</div>
          </div>
          <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all"
              style={{ width: `${Math.min((totals.kcal / (profile?.dailyProteinGoal || 2000)) * 100, 100)}%` }}
            />
          </div>
        </Card>

        {/* Nutrition Rings */}
        <Card className="mb-6 p-6">
          <NutritionRings
            protein={totals.protein}
            carbs={totals.carbs}
            fat={totals.fat}
            fiber={totals.fiber}
            onRingClick={(nutrient) => setSelectedNutrient(nutrient)}
          />
        </Card>

        {/* Water Intake */}
        <Card className="mb-6 p-4">
          <div className="flex items-center justify-between mb-2">
            <span className="font-medium">💧 Voda</span>
            <span className="text-muted">{waterTotal} / {profile?.dailyWaterGoal || 2000} ml</span>
          </div>
          <div className="w-full h-2 bg-muted rounded-full overflow-hidden mb-3">
            <div
              className="h-full bg-blue-500 transition-all"
              style={{ width: `${Math.min((waterTotal / (profile?.dailyWaterGoal || 2000)) * 100, 100)}%` }}
            />
          </div>
          <div className="flex gap-2">
            <Button
              onClick={() => addWaterMutation.mutate({ date: selectedDate, amount: 250 })}
              disabled={addWaterMutation.isPending}
              variant="outline"
              size="sm"
              className="flex-1 text-xs"
            >
              +250ml
            </Button>
            <Button
              onClick={() => addWaterMutation.mutate({ date: selectedDate, amount: 500 })}
              disabled={addWaterMutation.isPending}
              variant="outline"
              size="sm"
              className="flex-1 text-xs"
            >
              +500ml
            </Button>
          </div>
        </Card>

        {/* Meals by Slot */}
        {mealsLoading ? (
          <div className="flex justify-center py-8">
            <Loader2 className="animate-spin w-6 h-6" />
          </div>
        ) : (
          <div>
            {MEAL_SLOTS.map((slot) => {
              const slotMeals = meals?.filter((m) => m.slot === slot) || [];
              return (
                <div key={slot} className="meal-slot">
                  <div className="flex items-center justify-between mb-2">
                    <h3 className="font-semibold text-sm text-muted">{slot.toUpperCase()}</h3>
                    <button
                      onClick={() => {
                        setSelectedSlot(slot);
                        setShowAddMeal(true);
                      }}
                      className="text-xs text-indigo-600 hover:text-indigo-700 font-medium"
                    >
                      + Přidat
                    </button>
                  </div>
                  {slotMeals.map((meal) => (
                    <div key={meal.id}>
                      <Card
                        className="meal-entry cursor-pointer hover:bg-muted/50 transition-colors"
                        onClick={() => setExpandedMealId(expandedMealId === meal.id ? null : meal.id)}
                      >
                        <div>
                          <div className="font-medium">{meal.foodName}</div>
                          <div className="text-sm text-muted">{meal.portion}g</div>
                        </div>
                        <div className="text-right">
                          <div className="font-bold text-indigo-600">{meal.kcal} kcal</div>
                        </div>
                      </Card>
                      {expandedMealId === meal.id && (
                        <div className="mt-2">
                          <MealActions
                            mealId={meal.id}
                            foodName={meal.foodName}
                            portion={meal.portion}
                            kcal={meal.kcal}
                            protein={meal.protein}
                            carbs={meal.carbs}
                            fat={meal.fat}
                            fiber={meal.fiber}
                            onSuccess={() => refetchMeals()}
                          />
                        </div>
                      )}
                    </div>
                  ))}
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* FAB - Add Meal */}
      {/* Action Buttons */}
      <div className="fixed bottom-6 right-6 flex flex-col gap-3 safe-bottom">
        <button
          onClick={() => setShowCustomFoodEditor(true)}
          className="w-14 h-14 rounded-full bg-green-600 text-white shadow-lg flex items-center justify-center hover:bg-green-700 active:scale-95 transition-transform"
          title="Nový recept"
        >
          <span className="text-xl">📖</span>
        </button>
        <button
          onClick={() => setShowBarcodeScanner(true)}
          className="w-14 h-14 rounded-full bg-purple-600 text-white shadow-lg flex items-center justify-center hover:bg-purple-700 active:scale-95 transition-transform"
          title="Skener"
        >
          <span className="text-xl">📱</span>
        </button>
        <button
          onClick={() => {
            setSelectedSlot("Snídaně");
            setShowAddMeal(true);
          }}
          className="w-14 h-14 rounded-full bg-indigo-600 text-white shadow-lg flex items-center justify-center hover:bg-indigo-700 active:scale-95 transition-transform"
          title="Přidat jídlo"
        >
          <Plus className="w-6 h-6" />
        </button>
      </div>

      {/* Add Meal Modal */}
      <AddMealModal
        isOpen={showAddMeal}
        onClose={() => setShowAddMeal(false)}
        date={selectedDate}
        slot={selectedSlot}
        onSuccess={() => refetchMeals()}
      />

      {/* Barcode Scanner Modal */}
      <BarcodeScanner
        isOpen={showBarcodeScanner}
        onClose={() => setShowBarcodeScanner(false)}
        onFoodFound={(food) => {
          toast.success(`Nalezeno: ${food.name}`);
        }}
      />

      {/* Custom Food Editor Modal */}
      <CustomFoodEditor
        isOpen={showCustomFoodEditor}
        onClose={() => setShowCustomFoodEditor(false)}
        onSuccess={() => refetchMeals()}
      />

      {/* Nutrition Details Modal */}
      {selectedNutrient && meals && (
        <NutritionDetails
          nutrient={selectedNutrient}
          label={{
            protein: "Bílkoviny",
            carbs: "Sacharidy",
            fat: "Tuky",
            fiber: "Vláknina",
          }[selectedNutrient]}
          meals={meals}
          onClose={() => setSelectedNutrient(null)}
        />
      )}
    </div>
  );
}
