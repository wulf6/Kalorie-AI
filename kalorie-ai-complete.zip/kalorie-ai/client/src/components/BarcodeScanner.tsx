import { useState, useRef, useEffect } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { X, Loader2 } from "lucide-react";
import { toast } from "sonner";

interface BarcodeScannerProps {
  isOpen: boolean;
  onClose: () => void;
  onFoodFound: (food: {
    name: string;
    kcal: number;
    protein: number;
    carbs: number;
    fat: number;
    fiber: number;
  }) => void;
}

export function BarcodeScanner({ isOpen, onClose, onFoodFound }: BarcodeScannerProps) {
  const [isScanning, setIsScanning] = useState(false);
  const [manualBarcode, setManualBarcode] = useState("");
  const [isSearching, setIsSearching] = useState(false);
  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);

  useEffect(() => {
    if (!isOpen || !videoRef.current) return;

    const startCamera = async () => {
      try {
        const stream = await navigator.mediaDevices.getUserMedia({
          video: { facingMode: "environment" },
        });
        videoRef.current!.srcObject = stream;
        setIsScanning(true);
      } catch (err) {
        toast.error("Nelze přistupovat k fotoaparátu");
        console.error(err);
      }
    };

    startCamera();

    return () => {
      if (videoRef.current?.srcObject) {
        const tracks = (videoRef.current.srcObject as MediaStream).getTracks();
        tracks.forEach((track) => track.stop());
      }
    };
  }, [isOpen]);

  const searchBarcode = async (barcode: string) => {
    if (!barcode.trim()) {
      toast.error("Zadejte čárový kód");
      return;
    }

    setIsSearching(true);
    try {
      const response = await fetch(
        `https://world.openfoodfacts.org/api/v0/product/${barcode}.json`
      );
      const data = await response.json();

      if (data.status === 1 && data.product) {
        const product = data.product;
        const nutrition = product.nutriments || {};

        onFoodFound({
          name: product.product_name || "Neznámé jídlo",
          kcal: Math.round(nutrition["energy-kcal"] || nutrition["energy"] / 4.184 || 0),
          protein: Math.round(nutrition.proteins || 0),
          carbs: Math.round(nutrition.carbohydrates || 0),
          fat: Math.round(nutrition.fat || 0),
          fiber: Math.round(nutrition.fiber || 0),
        });

        toast.success("Jídlo nalezeno!");
        onClose();
      } else {
        toast.error("Jídlo nebylo nalezeno v databázi");
      }
    } catch (error) {
      toast.error("Chyba při vyhledávání");
      console.error(error);
    } finally {
      setIsSearching(false);
      setManualBarcode("");
    }
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
      <div className="w-full bg-background rounded-t-2xl p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Skener čárového kódu</h2>
          <button onClick={onClose} className="p-2 hover:bg-muted rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Camera View */}
        <Card className="mb-6 overflow-hidden bg-black">
          <video
            ref={videoRef}
            autoPlay
            playsInline
            className="w-full aspect-video object-cover"
          />
        </Card>

        {/* Manual Barcode Input */}
        <Card className="p-4 mb-6">
          <label className="block text-sm font-medium mb-2">Nebo zadejte čárový kód ručně</label>
          <div className="flex gap-2">
            <input
              type="text"
              value={manualBarcode}
              onChange={(e) => setManualBarcode(e.target.value)}
              onKeyPress={(e) => {
                if (e.key === "Enter") {
                  searchBarcode(manualBarcode);
                }
              }}
              placeholder="Zadejte EAN kód..."
              className="input-field flex-1"
            />
            <Button
              onClick={() => searchBarcode(manualBarcode)}
              disabled={isSearching}
              className="bg-indigo-600 hover:bg-indigo-700"
            >
              {isSearching ? <Loader2 className="animate-spin mr-2 w-4 h-4" /> : null}
              Hledat
            </Button>
          </div>
        </Card>

        {/* Close Button */}
        <Button onClick={onClose} variant="outline" className="w-full">
          Zavřít
        </Button>
      </div>
    </div>
  );
}
