import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { Trash2, Edit2, X, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { useState } from "react";

interface MealActionsProps {
  mealId: number;
  foodName: string;
  portion: number;
  kcal: number | null;
  protein: number | null;
  carbs: number | null;
  fat: number | null;
  fiber: number | null;
  onSuccess?: () => void;
}

export function MealActions({
  mealId,
  foodName,
  portion,
  kcal,
  protein,
  carbs,
  fat,
  fiber,
  onSuccess,
}: MealActionsProps) {
  const [isEditing, setIsEditing] = useState(false);
  const [editPortion, setEditPortion] = useState(portion);

  const deleteMutation = trpc.meals.delete.useMutation({
    onSuccess: () => {
      toast.success("Jídlo smazáno");
      onSuccess?.();
    },
    onError: () => {
      toast.error("Chyba při mazání jídla");
    },
  });

  const updateMutation = trpc.meals.update.useMutation({
    onSuccess: () => {
      toast.success("Jídlo aktualizováno");
      setIsEditing(false);
      onSuccess?.();
    },
    onError: () => {
      toast.error("Chyba při aktualizaci jídla");
    },
  });

  const handleUpdate = () => {
    if (editPortion === portion) {
      setIsEditing(false);
      return;
    }

    const multiplier = editPortion / portion;
    updateMutation.mutate({
      id: mealId,
      portion: editPortion,
      kcal: kcal ? Math.round(kcal * multiplier) : undefined,
      protein: protein ? Math.round(protein * multiplier) : undefined,
      carbs: carbs ? Math.round(carbs * multiplier) : undefined,
      fat: fat ? Math.round(fat * multiplier) : undefined,
      fiber: fiber ? Math.round(fiber * multiplier) : undefined,
    });
  };

  if (isEditing) {
    return (
      <Card className="p-4 bg-muted/50">
        <div className="space-y-3">
          <div>
            <label className="block text-sm font-medium mb-1">Gramáž (g)</label>
            <input
              type="number"
              value={editPortion}
              onChange={(e) => setEditPortion(parseInt(e.target.value) || portion)}
              className="input-field"
            />
          </div>
          <div className="flex gap-2">
            <Button
              onClick={handleUpdate}
              disabled={updateMutation.isPending}
              className="flex-1 bg-indigo-600 hover:bg-indigo-700"
            >
              {updateMutation.isPending ? <Loader2 className="animate-spin mr-2 w-4 h-4" /> : null}
              Uložit
            </Button>
            <Button
              onClick={() => {
                setIsEditing(false);
                setEditPortion(portion);
              }}
              variant="outline"
              className="flex-1"
            >
              Zrušit
            </Button>
          </div>
        </div>
      </Card>
    );
  }

  return (
    <div className="flex gap-2">
      <Button
        onClick={() => setIsEditing(true)}
        variant="outline"
        size="sm"
        className="flex-1"
      >
        <Edit2 className="w-4 h-4 mr-2" />
        Editovat
      </Button>
      <Button
        onClick={() => deleteMutation.mutate({ id: mealId })}
        disabled={deleteMutation.isPending}
        variant="outline"
        size="sm"
        className="flex-1 text-red-600 hover:text-red-700"
      >
        {deleteMutation.isPending ? <Loader2 className="animate-spin mr-2 w-4 h-4" /> : <Trash2 className="w-4 h-4 mr-2" />}
        Smazat
      </Button>
    </div>
  );
}
