import { useState } from "react";

interface NutritionRingsProps {
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
  onRingClick: (nutrient: "protein" | "carbs" | "fat" | "fiber") => void;
}

const NUTRIENTS = [
  { key: "protein", label: "Bílkoviny", color: "#3b82f6", bgColor: "#dbeafe" },
  { key: "carbs", label: "Sacharidy", color: "#f59e0b", bgColor: "#fef3c7" },
  { key: "fat", label: "Tuky", color: "#10b981", bgColor: "#d1fae5" },
  { key: "fiber", label: "Vláknina", color: "#8b5cf6", bgColor: "#ede9fe" },
];

export function NutritionRings({
  protein,
  carbs,
  fat,
  fiber,
  onRingClick,
}: NutritionRingsProps) {
  const values = { protein, carbs, fat, fiber };

  return (
    <div className="grid grid-cols-2 gap-4">
      {NUTRIENTS.map((nut) => {
        const value = values[nut.key as keyof typeof values];
        const circumference = 2 * Math.PI * 45;
        const strokeDashoffset = circumference * 0.75; // 75% filled by default

        return (
          <button
            key={nut.key}
            onClick={() => onRingClick(nut.key as any)}
            className="flex flex-col items-center transition-transform hover:scale-105 active:scale-95"
          >
            <div className="relative w-24 h-24 mb-3">
              <svg
                className="absolute inset-0 transform -rotate-90"
                width="96"
                height="96"
                viewBox="0 0 100 100"
              >
                {/* Background ring */}
                <circle
                  cx="50"
                  cy="50"
                  r="45"
                  fill="none"
                  stroke={nut.bgColor}
                  strokeWidth="8"
                />
                {/* Progress ring */}
                <circle
                  cx="50"
                  cy="50"
                  r="45"
                  fill="none"
                  stroke={nut.color}
                  strokeWidth="8"
                  strokeDasharray={circumference}
                  strokeDashoffset={strokeDashoffset}
                  strokeLinecap="round"
                  className="transition-all duration-300"
                />
              </svg>
              {/* Center text */}
              <div className="absolute inset-0 flex flex-col items-center justify-center">
                <div className="text-lg font-bold" style={{ color: nut.color }}>
                  {Math.round(value)}g
                </div>
              </div>
            </div>
            <div className="text-sm font-medium text-center">{nut.label}</div>
          </button>
        );
      })}
    </div>
  );
}
