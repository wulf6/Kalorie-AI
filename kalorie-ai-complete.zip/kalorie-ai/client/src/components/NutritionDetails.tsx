import { Card } from "@/components/ui/card";
import { X } from "lucide-react";

interface Meal {
  id: number;
  foodName: string;
  portion: number;
  kcal: number | null;
  protein: number | null;
  carbs: number | null;
  fat: number | null;
  fiber: number | null;
}

interface NutritionDetailsProps {
  nutrient: "protein" | "carbs" | "fat" | "fiber";
  label: string;
  meals: Meal[];
  onClose: () => void;
}

export function NutritionDetails({ nutrient, label, meals, onClose }: NutritionDetailsProps) {
  const nutrientKey = nutrient as keyof Meal;
  const nutrientValues = meals
    .map((meal) => ({
      ...meal,
      value: meal[nutrientKey] as number | undefined,
    }))
    .filter((m) => m.value && m.value > 0)
    .sort((a, b) => (b.value || 0) - (a.value || 0));

  const total = nutrientValues.reduce((sum, m) => sum + (m.value || 0), 0);

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
      <div className="w-full bg-background rounded-t-2xl p-6 max-h-[80vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">{label}</h2>
          <button onClick={onClose} className="p-2 hover:bg-muted rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        <Card className="mb-6 p-4 bg-gradient-to-r from-indigo-50 to-blue-50 dark:from-indigo-950 dark:to-blue-950">
          <div className="text-center">
            <div className="text-4xl font-bold text-indigo-600">{total.toFixed(1)}g</div>
            <div className="text-sm text-muted">Celkem</div>
          </div>
        </Card>

        {nutrientValues.length > 0 ? (
          <div className="space-y-3">
            {nutrientValues.map((meal) => {
              const percentage = total > 0 ? ((meal.value || 0) / total) * 100 : 0;
              return (
                <Card key={meal.id} className="p-4">
                  <div className="flex items-center justify-between mb-2">
                    <div>
                      <div className="font-medium">{meal.foodName}</div>
                      <div className="text-sm text-muted">{meal.portion}g</div>
                    </div>
                    <div className="text-right">
                      <div className="font-bold text-indigo-600">{meal.value?.toFixed(1) || 0}g</div>
                      <div className="text-xs text-muted">{percentage.toFixed(0)}%</div>
                    </div>
                  </div>
                  <div className="w-full h-2 bg-muted rounded-full overflow-hidden">
                    <div
                      className="h-full bg-gradient-to-r from-indigo-500 to-purple-500 transition-all"
                      style={{ width: `${percentage}%` }}
                    />
                  </div>
                </Card>
              );
            })}
          </div>
        ) : (
          <Card className="p-8 text-center text-muted">
            <p>Žádná jídla obsahující {label.toLowerCase()}</p>
          </Card>
        )}
      </div>
    </div>
  );
}
