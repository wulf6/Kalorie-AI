import { useState } from "react";
import { Card } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { X, Plus, Trash2, Loader2 } from "lucide-react";
import { toast } from "sonner";
import { trpc } from "@/lib/trpc";

interface Ingredient {
  name: string;
  portion: number;
  kcal: number;
  protein: number;
  carbs: number;
  fat: number;
  fiber: number;
}

interface CustomFoodEditorProps {
  isOpen: boolean;
  onClose: () => void;
  onSuccess?: () => void;
}

const FOOD_DB = [
  { name: "Banán", kcal: 89, protein: 1, carbs: 23, fat: 0, fiber: 3 },
  { name: "Jablko", kcal: 52, protein: 0, carbs: 14, fat: 0, fiber: 2 },
  { name: "Kuřecí prsa", kcal: 165, protein: 31, carbs: 0, fat: 4, fiber: 0 },
  { name: "Rýže", kcal: 130, protein: 3, carbs: 28, fat: 0, fiber: 0 },
  { name: "Brambory", kcal: 77, protein: 2, carbs: 17, fat: 0, fiber: 2 },
  { name: "Sůl", kcal: 0, protein: 0, carbs: 0, fat: 0, fiber: 0 },
];

export function CustomFoodEditor({ isOpen, onClose, onSuccess }: CustomFoodEditorProps) {
  const [recipeName, setRecipeName] = useState("");
  const [ingredients, setIngredients] = useState<Ingredient[]>([]);
  const [currentIngredient, setCurrentIngredient] = useState<Ingredient>({
    name: "",
    portion: 100,
    kcal: 0,
    protein: 0,
    carbs: 0,
    fat: 0,
    fiber: 0,
  });
  const [suggestions, setSuggestions] = useState<typeof FOOD_DB>([]);

  const saveMutation = trpc.customFoods.add.useMutation({
    onSuccess: () => {
      toast.success("Recept uložen!");
      setRecipeName("");
      setIngredients([]);
      onSuccess?.();
      onClose();
    },
    onError: () => {
      toast.error("Chyba při ukládání receptu");
    },
  });

  const handleAddIngredient = () => {
    if (!currentIngredient.name) {
      toast.error("Vyberte potravinu");
      return;
    }

    setIngredients([...ingredients, currentIngredient]);
    setCurrentIngredient({
      name: "",
      portion: 100,
      kcal: 0,
      protein: 0,
      carbs: 0,
      fat: 0,
      fiber: 0,
    });
    setSuggestions([]);
  };

  const handleSelectFood = (food: (typeof FOOD_DB)[0]) => {
    setCurrentIngredient({
      name: food.name,
      portion: 100,
      kcal: food.kcal,
      protein: food.protein,
      carbs: food.carbs,
      fat: food.fat,
      fiber: food.fiber,
    });
    setSuggestions([]);
  };

  const handleSaveRecipe = () => {
    if (!recipeName.trim()) {
      toast.error("Zadejte název receptu");
      return;
    }

    if (ingredients.length === 0) {
      toast.error("Přidejte alespoň jednu ingredienci");
      return;
    }

    const totalKcal = ingredients.reduce((sum, ing) => sum + ing.kcal, 0);
    const totalProtein = ingredients.reduce((sum, ing) => sum + ing.protein, 0);
    const totalCarbs = ingredients.reduce((sum, ing) => sum + ing.carbs, 0);
    const totalFat = ingredients.reduce((sum, ing) => sum + ing.fat, 0);
    const totalFiber = ingredients.reduce((sum, ing) => sum + ing.fiber, 0);

    saveMutation.mutate({
      name: recipeName,
      ingredients: ingredients,
    });
  };

  if (!isOpen) return null;

  const totalKcal = ingredients.reduce((sum, ing) => sum + ing.kcal, 0);
  const totalProtein = ingredients.reduce((sum, ing) => sum + ing.protein, 0);
  const totalCarbs = ingredients.reduce((sum, ing) => sum + ing.carbs, 0);
  const totalFat = ingredients.reduce((sum, ing) => sum + ing.fat, 0);
  const totalFiber = ingredients.reduce((sum, ing) => sum + ing.fiber, 0);

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
      <div className="w-full bg-background rounded-t-2xl p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Nový recept</h2>
          <button onClick={onClose} className="p-2 hover:bg-muted rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Recipe Name */}
        <Card className="p-4 mb-6">
          <label className="block text-sm font-medium mb-2">Název receptu</label>
          <input
            type="text"
            value={recipeName}
            onChange={(e) => setRecipeName(e.target.value)}
            placeholder="Např. Kuřecí salát"
            className="input-field w-full"
          />
        </Card>

        {/* Add Ingredient */}
        <Card className="p-4 mb-6">
          <label className="block text-sm font-medium mb-2">Přidat ingredienci</label>
          <div className="space-y-3">
            <div>
              <input
                type="text"
                value={currentIngredient.name}
                onChange={(e) => {
                  const value = e.target.value;
                  setCurrentIngredient({ ...currentIngredient, name: value });
                  if (value) {
                    setSuggestions(
                      FOOD_DB.filter((f) =>
                        f.name.toLowerCase().includes(value.toLowerCase())
                      )
                    );
                  } else {
                    setSuggestions([]);
                  }
                }}
                placeholder="Vyhledejte potravinu..."
                className="input-field w-full"
              />
              {suggestions.length > 0 && (
                <div className="mt-2 space-y-1">
                  {suggestions.map((food) => (
                    <button
                      key={food.name}
                      onClick={() => handleSelectFood(food)}
                      className="w-full text-left p-2 hover:bg-muted rounded text-sm"
                    >
                      {food.name}
                    </button>
                  ))}
                </div>
              )}
            </div>

            <div>
              <label className="text-xs text-muted">Gramáž (g)</label>
              <input
                type="number"
                value={currentIngredient.portion}
                onChange={(e) =>
                  setCurrentIngredient({
                    ...currentIngredient,
                    portion: parseInt(e.target.value) || 100,
                  })
                }
                className="input-field w-full"
              />
            </div>

            <Button
              onClick={handleAddIngredient}
              className="w-full bg-indigo-600 hover:bg-indigo-700"
            >
              <Plus className="w-4 h-4 mr-2" />
              Přidat ingredienci
            </Button>
          </div>
        </Card>

        {/* Ingredients List */}
        {ingredients.length > 0 && (
          <Card className="p-4 mb-6">
            <h3 className="font-semibold mb-3">Ingredience ({ingredients.length})</h3>
            <div className="space-y-2">
              {ingredients.map((ing, idx) => (
                <div key={idx} className="flex items-center justify-between p-2 bg-muted rounded">
                  <div className="flex-1">
                    <div className="font-medium text-sm">{ing.name}</div>
                    <div className="text-xs text-muted">{ing.portion}g • {ing.kcal} kcal</div>
                  </div>
                  <button
                    onClick={() => setIngredients(ingredients.filter((_, i) => i !== idx))}
                    className="p-1 hover:bg-background rounded"
                  >
                    <Trash2 className="w-4 h-4 text-red-600" />
                  </button>
                </div>
              ))}
            </div>
          </Card>
        )}

        {/* Totals */}
        {ingredients.length > 0 && (
          <Card className="p-4 mb-6 bg-gradient-to-r from-indigo-50 to-blue-50 dark:from-indigo-950 dark:to-blue-950">
            <h3 className="font-semibold mb-3">Celkem na recept</h3>
            <div className="grid grid-cols-2 gap-2 text-sm">
              <div>
                <div className="text-2xl font-bold text-indigo-600">{totalKcal}</div>
                <div className="text-muted">kcal</div>
              </div>
              <div>
                <div className="text-lg font-semibold">P: {totalProtein}g</div>
                <div className="text-lg font-semibold">S: {totalCarbs}g</div>
              </div>
              <div>
                <div className="text-lg font-semibold">T: {totalFat}g</div>
                <div className="text-lg font-semibold">V: {totalFiber}g</div>
              </div>
            </div>
          </Card>
        )}

        {/* Buttons */}
        <div className="flex gap-2">
          <Button
            onClick={handleSaveRecipe}
            disabled={saveMutation.isPending || ingredients.length === 0}
            className="flex-1 bg-indigo-600 hover:bg-indigo-700"
          >
            {saveMutation.isPending ? <Loader2 className="animate-spin mr-2 w-4 h-4" /> : null}
            Uložit recept
          </Button>
          <Button onClick={onClose} variant="outline" className="flex-1">
            Zrušit
          </Button>
        </div>
      </div>
    </div>
  );
}
