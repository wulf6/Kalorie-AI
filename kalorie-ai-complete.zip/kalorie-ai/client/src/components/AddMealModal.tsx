import { useState } from "react";
import { trpc } from "@/lib/trpc";
import { Button } from "@/components/ui/button";
import { Card } from "@/components/ui/card";
import { X, Loader2, Sparkles } from "lucide-react";
import { toast } from "sonner";

const FOOD_DB: Record<string, [string, number, number, number, number, number]> = {
  "banán": ["banán", 89, 1.1, 23, 0.3, 2.6],
  "jablko": ["jablko", 52, 0.3, 14, 0.2, 2.4],
  "kuřecí prsa": ["kuřecí prsa", 165, 31, 0, 3.6, 0],
  "rýže": ["rýže", 130, 2.7, 28, 0.3, 0.4],
  "chléb": ["chléb", 265, 9, 49, 3.3, 7],
  "máslo": ["máslo", 717, 0.9, 0.1, 81, 0],
  "mléko": ["mléko", 61, 3.2, 4.8, 3.3, 0],
  "vejce": ["vejce", 155, 13, 1.1, 11, 0],
};

interface AddMealModalProps {
  isOpen: boolean;
  onClose: () => void;
  date: string;
  slot: string;
  onSuccess?: () => void;
}

export function AddMealModal({ isOpen, onClose, date, slot, onSuccess }: AddMealModalProps) {
  const [tab, setTab] = useState<"manual" | "ai" | "barcode" | "recipe">("manual");
  const [foodName, setFoodName] = useState("");
  const [portion, setPortion] = useState(100);
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [aiDescription, setAiDescription] = useState("");

  const addMealMutation = trpc.meals.add.useMutation({
    onSuccess: () => {
      toast.success("Jídlo přidáno");
      setFoodName("");
      setPortion(100);
      setAiDescription("");
      onClose();
      onSuccess?.();
    },
    onError: () => {
      toast.error("Chyba při přidávání jídla");
    },
  });

  const aiMutation = trpc.ai.analyzeMeal.useMutation({
    onSuccess: (data) => {
      setFoodName(data.foodName);
      setPortion(data.portion);
      // Automatically add the meal
      addMealMutation.mutate({
        date,
        slot,
        foodName: data.foodName,
        portion: data.portion,
        kcal: Math.round(data.kcal),
        protein: Math.round(data.protein * 10),
        carbs: Math.round(data.carbs),
        fat: Math.round(data.fat),
        fiber: Math.round(data.fiber),
        source: "ai",
      });
    },
    onError: () => {
      toast.error("Chyba při AI analýze");
    },
  });

  const handleFoodSearch = (query: string) => {
    setFoodName(query);
    if (query.length < 2) {
      setSuggestions([]);
      return;
    }
    const matches = Object.keys(FOOD_DB).filter((key) => key.includes(query.toLowerCase()));
    setSuggestions(matches.slice(0, 5));
  };

  const handleSelectFood = (food: string) => {
    setFoodName(food);
    setSuggestions([]);
  };

  const handleAddManual = () => {
    if (!foodName) {
      toast.error("Zadej název jídla");
      return;
    }

    const foodData = FOOD_DB[foodName.toLowerCase()];
    if (!foodData) {
      toast.error("Jídlo nenalezeno v databázi");
      return;
    }

    const [name, kcal100, protein100, carbs100, fat100, fiber100] = foodData;
    const multiplier = portion / 100;

    addMealMutation.mutate({
      date,
      slot,
      foodName: name,
      portion,
      kcal: Math.round(kcal100 * multiplier),
      protein: Math.round(protein100 * multiplier * 10),
      carbs: Math.round(carbs100 * multiplier),
      fat: Math.round(fat100 * multiplier),
      fiber: Math.round(fiber100 * multiplier),
      source: "manual",
    });
  };

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-end">
      <div className="w-full bg-background rounded-t-2xl p-6 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between mb-6">
          <h2 className="text-2xl font-bold">Přidat jídlo</h2>
          <button onClick={onClose} className="p-2 hover:bg-muted rounded-lg">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tabs */}
        <div className="flex gap-2 mb-6 border-b border-border">
          {(["manual", "ai", "barcode", "recipe"] as const).map((t) => (
            <button
              key={t}
              onClick={() => setTab(t)}
              className={`pb-2 px-4 font-medium transition-colors ${
                tab === t ? "border-b-2 border-indigo-600 text-indigo-600" : "text-muted"
              }`}
            >
              {t === "manual" && "Ruční"}
              {t === "ai" && "AI"}
              {t === "barcode" && "Čárový kód"}
              {t === "recipe" && "Recept"}
            </button>
          ))}
        </div>

        {/* Manual Tab */}
        {tab === "manual" && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Jídlo</label>
              <div className="relative">
                <input
                  type="text"
                  value={foodName}
                  onChange={(e) => handleFoodSearch(e.target.value)}
                  placeholder="Hledej jídlo..."
                  className="input-field"
                />
                {suggestions.length > 0 && (
                  <div className="absolute top-full left-0 right-0 mt-1 bg-card border border-border rounded-lg shadow-lg z-10">
                    {suggestions.map((food) => (
                      <button
                        key={food}
                        onClick={() => handleSelectFood(food)}
                        className="w-full text-left px-4 py-2 hover:bg-muted transition-colors"
                      >
                        {food}
                      </button>
                    ))}
                  </div>
                )}
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium mb-2">Gramáž (g)</label>
              <input
                type="number"
                value={portion}
                onChange={(e) => setPortion(parseInt(e.target.value) || 100)}
                className="input-field"
              />
            </div>
            <Button
              onClick={handleAddManual}
              disabled={addMealMutation.isPending}
              className="w-full bg-indigo-600 hover:bg-indigo-700"
            >
              {addMealMutation.isPending ? <Loader2 className="animate-spin mr-2 w-4 h-4" /> : null}
              Přidat jídlo
            </Button>
          </div>
        )}

        {/* AI Tab */}
        {tab === "ai" && (
          <div className="space-y-4">
            <div>
              <label className="block text-sm font-medium mb-2">Popis jídla</label>
              <textarea
                value={aiDescription}
                onChange={(e) => setAiDescription(e.target.value)}
                placeholder="Např: Snídam 2 vejce s chlebem a máslem"
                className="input-field h-24 resize-none"
              />
            </div>
            <Button
              onClick={() => aiMutation.mutate({ description: aiDescription })}
              disabled={aiMutation.isPending || !aiDescription}
              className="w-full bg-indigo-600 hover:bg-indigo-700"
            >
              {aiMutation.isPending ? (
                <Loader2 className="animate-spin mr-2 w-4 h-4" />
              ) : (
                <Sparkles className="mr-2 w-4 h-4" />
              )}
              Analyzovat s AI
            </Button>
          </div>
        )}

        {/* Barcode Tab */}
        {tab === "barcode" && (
          <Card className="p-6 text-center text-muted">
            <p>Skener čárových kódů - brzy dostupný</p>
          </Card>
        )}

        {/* Recipe Tab */}
        {tab === "recipe" && (
          <Card className="p-6 text-center text-muted">
            <p>Vlastní recepty - brzy dostupné</p>
          </Card>
        )}
      </div>
    </div>
  );
}
