import { eq, desc } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import { InsertUser, users, userProfiles, InsertUserProfile, meals, InsertMeal, customFoods, InsertCustomFood, weightHistory, InsertWeightEntry, waterIntake, InsertWaterEntry } from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

// Lazily create the drizzle instance so local tooling can run without a DB.
export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }

  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }

  try {
    const values: InsertUser = {
      openId: user.openId,
    };
    const updateSet: Record<string, unknown> = {};

    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];

    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };

    textFields.forEach(assignNullable);

    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }

    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }

    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }

    await db.insert(users).values(values).onDuplicateKeyUpdate({
      set: updateSet,
    });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot get user: database not available");
    return undefined;
  }

  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);

  return result.length > 0 ? result[0] : undefined;
}

// ── User Profile ──
export async function getUserProfile(userId: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(userProfiles).where(eq(userProfiles.userId, userId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

export async function upsertUserProfile(userId: number, data: Partial<InsertUserProfile>) {
  const db = await getDb();
  if (!db) return;
  await db.insert(userProfiles).values({ userId, ...data }).onDuplicateKeyUpdate({
    set: data,
  });
}

// ── Meals ──
export async function getMealsForDate(userId: number, date: string) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(meals).where(eq(meals.userId, userId) && eq(meals.date, date));
}

export async function addMeal(data: InsertMeal) {
  const db = await getDb();
  if (!db) return;
  await db.insert(meals).values(data);
}

export async function updateMeal(id: number, data: Partial<InsertMeal>) {
  const db = await getDb();
  if (!db) return;
  await db.update(meals).set(data).where(eq(meals.id, id));
}

export async function deleteMeal(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(meals).where(eq(meals.id, id));
}

// ── Custom Foods ──
export async function getCustomFoods(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(customFoods).where(eq(customFoods.userId, userId));
}

export async function addCustomFood(data: InsertCustomFood) {
  const db = await getDb();
  if (!db) return;
  await db.insert(customFoods).values(data);
}

export async function deleteCustomFood(id: number) {
  const db = await getDb();
  if (!db) return;
  await db.delete(customFoods).where(eq(customFoods.id, id));
}

// ── Weight History ──
export async function getWeightHistory(userId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(weightHistory).where(eq(weightHistory.userId, userId)).orderBy(desc(weightHistory.date));
}

export async function addWeightEntry(data: InsertWeightEntry) {
  const db = await getDb();
  if (!db) return;
  await db.insert(weightHistory).values(data);
}

// ── Water Intake ──
export async function getWaterForDate(userId: number, date: string) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(waterIntake).where(eq(waterIntake.userId, userId) && eq(waterIntake.date, date));
}

export async function addWaterEntry(data: InsertWaterEntry) {
  const db = await getDb();
  if (!db) return;
  await db.insert(waterIntake).values(data);
}
