import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import { invokeLLM } from "./_core/llm";
import {
  getUserProfile,
  upsertUserProfile,
  getMealsForDate,
  addMeal,
  updateMeal,
  deleteMeal,
  getCustomFoods,
  addCustomFood,
  deleteCustomFood,
  getWeightHistory,
  addWeightEntry,
  getWaterForDate,
  addWaterEntry,
} from "./db";

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ── Profile ──
  profile: router({
    get: protectedProcedure.query(async ({ ctx }) => {
      return await getUserProfile(ctx.user.id);
    }),
    update: protectedProcedure
      .input(
        z.object({
          age: z.number().optional(),
          gender: z.enum(["male", "female", "other"]).optional(),
          height: z.number().optional(),
          weight: z.number().optional(),
          activityLevel: z.enum(["sedentary", "light", "moderate", "active", "veryActive"]).optional(),
          goalWeight: z.number().optional(),
          goalTempo: z.enum(["slow", "moderate", "fast"]).optional(),
          dailyWaterGoal: z.number().optional(),
          dailyProteinGoal: z.number().optional(),
          dailyCarbsGoal: z.number().optional(),
          dailyFatGoal: z.number().optional(),
          dailyFiberGoal: z.number().optional(),
        })
      )
      .mutation(async ({ ctx, input }) => {
        await upsertUserProfile(ctx.user.id, input);
        return { success: true };
      }),
  }),

  // ── Meals ──
  meals: router({
    getForDate: protectedProcedure
      .input(z.object({ date: z.string() }))
      .query(async ({ ctx, input }) => {
        return await getMealsForDate(ctx.user.id, input.date);
      }),
    add: protectedProcedure
      .input(
        z.object({
          date: z.string(),
          slot: z.string(),
          foodName: z.string(),
          portion: z.number(),
          kcal: z.number().optional(),
          protein: z.number().optional(),
          carbs: z.number().optional(),
          fat: z.number().optional(),
          fiber: z.number().optional(),
          source: z.enum(["manual", "ai", "barcode", "recipe"]).default("manual"),
        })
      )
      .mutation(async ({ ctx, input }) => {
        await addMeal({ ...input, userId: ctx.user.id });
        return { success: true };
      }),
    update: protectedProcedure
      .input(
        z.object({
          id: z.number(),
          portion: z.number().optional(),
          kcal: z.number().optional(),
          protein: z.number().optional(),
          carbs: z.number().optional(),
          fat: z.number().optional(),
          fiber: z.number().optional(),
        })
      )
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        await updateMeal(id, data);
        return { success: true };
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteMeal(input.id);
        return { success: true };
      }),
  }),

  // ── AI Food Analysis ──
  ai: router({
    analyzeMeal: protectedProcedure
      .input(z.object({ description: z.string() }))
      .mutation(async ({ input }) => {
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content:
                'You are a nutrition expert. Analyze the meal description and return ONLY a JSON object with: {foodName: string, portion: number, unit: "g"|"ml", kcal: number, protein: number, carbs: number, fat: number, fiber: number}. All nutritional values should be for the specified portion.',
            },
            {
              role: "user",
              content: `Analyze this meal: ${input.description}`,
            },
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "meal_analysis",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  foodName: { type: "string" },
                  portion: { type: "number" },
                  unit: { type: "string", enum: ["g", "ml"] },
                  kcal: { type: "number" },
                  protein: { type: "number" },
                  carbs: { type: "number" },
                  fat: { type: "number" },
                  fiber: { type: "number" },
                },
                required: ["foodName", "portion", "unit", "kcal", "protein", "carbs", "fat", "fiber"],
                additionalProperties: false,
              },
            },
          },
        });

        const content = response.choices[0]?.message.content;
        if (!content || typeof content !== 'string') throw new Error("No response from AI");

        return JSON.parse(content);
      }),
  }),

  // ── Custom Foods ──
  customFoods: router({
    list: protectedProcedure.query(async ({ ctx }) => {
      return await getCustomFoods(ctx.user.id);
    }),
    add: protectedProcedure
      .input(
        z.object({
          name: z.string(),
          ingredients: z.array(
            z.object({
              name: z.string(),
              portion: z.number(),
              kcal: z.number(),
              protein: z.number(),
              carbs: z.number(),
              fat: z.number(),
              fiber: z.number(),
            })
          ),
        })
      )
      .mutation(async ({ ctx, input }) => {
        const totals = input.ingredients.reduce(
          (acc, ing) => ({
            kcal: acc.kcal + ing.kcal,
            protein: acc.protein + ing.protein,
            carbs: acc.carbs + ing.carbs,
            fat: acc.fat + ing.fat,
            fiber: acc.fiber + ing.fiber,
          }),
          { kcal: 0, protein: 0, carbs: 0, fat: 0, fiber: 0 }
        );

        await addCustomFood({
          userId: ctx.user.id,
          name: input.name,
          ingredients: JSON.stringify(input.ingredients),
          totalKcal: totals.kcal,
          totalProtein: totals.protein,
          totalCarbs: totals.carbs,
          totalFat: totals.fat,
          totalFiber: totals.fiber,
        });

        return { success: true };
      }),
    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteCustomFood(input.id);
        return { success: true };
      }),
  }),

  // ── Weight History ──
  weight: router({
    getHistory: protectedProcedure.query(async ({ ctx }) => {
      return await getWeightHistory(ctx.user.id);
    }),
    add: protectedProcedure
      .input(z.object({ date: z.string(), weight: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await addWeightEntry({
          userId: ctx.user.id,
          date: input.date,
          weight: input.weight,
        });
        return { success: true };
      }),
  }),

  // ── Water Intake ──
  water: router({
    getForDate: protectedProcedure
      .input(z.object({ date: z.string() }))
      .query(async ({ ctx, input }) => {
        return await getWaterForDate(ctx.user.id, input.date);
      }),
    add: protectedProcedure
      .input(z.object({ date: z.string(), amount: z.number() }))
      .mutation(async ({ ctx, input }) => {
        await addWaterEntry({
          userId: ctx.user.id,
          date: input.date,
          amount: input.amount,
        });
        return { success: true };
      }),
  }),
});

export type AppRouter = typeof appRouter;
