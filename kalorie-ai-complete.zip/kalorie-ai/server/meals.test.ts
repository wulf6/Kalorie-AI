import { describe, it, expect, beforeEach, vi } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(userId: number = 1): TrpcContext {
  const user: AuthenticatedUser = {
    id: userId,
    openId: `user-${userId}`,
    email: `user${userId}@example.com`,
    name: `User ${userId}`,
    loginMethod: "manus",
    role: "user",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  return {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {} as TrpcContext["res"],
  };
}

describe("meals router", () => {
  it("should add a meal for the authenticated user", async () => {
    const ctx = createAuthContext(1);
    const caller = appRouter.createCaller(ctx);

    const result = await caller.meals.add({
      date: "2026-04-15",
      slot: "Snídaně",
      foodName: "Banán",
      portion: 100,
      kcal: 89,
      protein: 1,
      carbs: 23,
      fat: 0,
      fiber: 3,
      source: "manual",
    });

    expect(result.success).toBe(true);
  });

  it("should get meals for a specific date", async () => {
    const ctx = createAuthContext(1);
    const caller = appRouter.createCaller(ctx);

    // Get meals for that date (should include meals from previous tests)
    const meals = await caller.meals.getForDate({ date: "2026-04-15" });

    expect(Array.isArray(meals)).toBe(true);
    // Should have at least one meal from previous tests
    expect(meals.length).toBeGreaterThan(0);
    // Just verify the first meal has required properties
    expect(meals[0]?.foodName).toBeDefined();
    expect(meals[0]?.portion).toBeDefined();
  });

  it("should delete a meal", async () => {
    const ctx = createAuthContext(1);
    const caller = appRouter.createCaller(ctx);

    // Add a meal first
    await caller.meals.add({
      date: "2026-04-16",
      slot: "Oběd",
      foodName: "Test jídlo",
      portion: 100,
      kcal: 100,
      protein: 10,
      carbs: 10,
      fat: 5,
      fiber: 1,
      source: "manual",
    });

    const meals1 = await caller.meals.getForDate({ date: "2026-04-16" });
    const initialCount = meals1.length;

    // Delete the first meal if exists
    if (initialCount > 0 && meals1[0]) {
      await caller.meals.delete({ id: meals1[0].id });

      // Verify deletion
      const meals2 = await caller.meals.getForDate({ date: "2026-04-16" });
      expect(meals2.length).toBeLessThan(initialCount);
    }
  });
});

describe("profile router", () => {
  it("should update user profile", async () => {
    const ctx = createAuthContext(1);
    const caller = appRouter.createCaller(ctx);

    const result = await caller.profile.update({
      age: 30,
      gender: "male",
      height: 180,
      weight: 80,
      goalWeight: 75,
      activityLevel: "moderate",
      goalTempo: "moderate",
      dailyWaterGoal: 2000,
      dailyProteinGoal: 150,
      dailyCarbsGoal: 225,
      dailyFatGoal: 67,
      dailyFiberGoal: 30,
    });

    expect(result.success).toBe(true);
  });

  it("should get user profile", async () => {
    const ctx = createAuthContext(1);
    const caller = appRouter.createCaller(ctx);

    // Update profile first
    await caller.profile.update({
      age: 28,
      gender: "female",
      height: 165,
      weight: 65,
      goalWeight: 60,
      activityLevel: "light",
      goalTempo: "slow",
      dailyWaterGoal: 1800,
    });

    // Get profile
    const profile = await caller.profile.get();

    expect(profile).toBeDefined();
    expect(profile?.age).toBe(28);
    expect(profile?.gender).toBe("female");
  });
});

describe("water router", () => {
  it("should add water entry", async () => {
    const ctx = createAuthContext(1);
    const caller = appRouter.createCaller(ctx);

    const result = await caller.water.add({
      date: "2026-04-17",
      amount: 250,
    });

    expect(result.success).toBe(true);
  });

  it("should get water entries for a date", async () => {
    const ctx = createAuthContext(1);
    const caller = appRouter.createCaller(ctx);

    // Add water entry
    await caller.water.add({
      date: "2026-04-17",
      amount: 500,
    });

    // Get entries
    const entries = await caller.water.getForDate({ date: "2026-04-17" });

    expect(Array.isArray(entries)).toBe(true);
    expect(entries.length).toBeGreaterThan(0);
  });
});
